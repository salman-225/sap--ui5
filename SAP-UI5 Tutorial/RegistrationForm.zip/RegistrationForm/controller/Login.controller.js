sap.ui.define([
    './BaseController.controller'
  ], function (Controller) {
    "use strict";
  
    return Controller.extend("app.controller.Login", {
      onInit: function () {
        this.hardcodedUsername = "admin";
        this.hardcodedPassword = "password123";
      },
  
      onLogin: function () {
        var enteredUsername = this.byId("usernameInput").getValue();
        var enteredPassword = this.byId("passwordInput").getValue();
      
        if (enteredUsername === this.hardcodedUsername && enteredPassword === this.hardcodedPassword) {
         var oRouter=this.getRouter();
            oRouter.navTo("form");
        } else {
          alert("Please Enter the correct username or password")
        }
      }
    });
  });